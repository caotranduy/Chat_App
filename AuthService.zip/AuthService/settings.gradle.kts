rootProject.name = "AuthService"
